package az.vtb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Testing2rpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Testing2rpcApplication.class, args);
	}

}
