package az.vtb;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.logging.Logger;


@Service
public class LocalServiceImpl  {

    public String resultData(int a) {


        for (int i = 0; i < 100000000; i++) {
            if(i%a==0){
                a+=i;
            }
        }
        for (int i = 0; i < 100000000; i++) {
            if(i%a==0){
                a+=i;
            }
        }
        for (int i = 0; i < 100000000; i++) {
            if(i%a==0){
                a+=i;
            }
        }
        for (int i = 0; i < 100000000; i++) {
            if(i%a==0){
                a+=i;
            }
        }
        for (int i = 0; i < 100000000; i++) {
            if(i%a==0){
                a+=i;
            }
        }




        return String.valueOf(a);
    }

}
