package az.vtb.grpc;


import az.vtb.LocalServiceGrpc;
import az.vtb.TestingGRPCApp;
import io.grpc.stub.StreamObserver;
import org.springframework.stereotype.Service;

import java.util.logging.Logger;


@Service
public class LocalServiceImpl extends LocalServiceGrpc.LocalServiceImplBase {
    private static final Logger LOGGER = Logger.getLogger(LocalServiceImpl.class.getName());


    @Override
    public void pay(TestingGRPCApp.requestDTO request, StreamObserver<TestingGRPCApp.responseDTO> response) {
        LOGGER.info("gRPC request " + request.toString());
        var data = resultData(request.getId());

        TestingGRPCApp.responseDTO gRPCResponse = TestingGRPCApp.
                responseDTO.newBuilder()

                .setResult(data)
                .build();
        response.onNext(gRPCResponse);
        response.onCompleted();
    }

    public String resultData(int a) {


        for (int i = 0; i < 100000000; i++) {
            if (i % a == 0) {
                a += i;
            }
        }
        for (int i = 0; i < 100000000; i++) {
            if (i % a == 0) {
                a += i;
            }
        }
        for (int i = 0; i < 100000000; i++) {
            if (i % a == 0) {
                a += i;
            }
        }
        for (int i = 0; i < 100000000; i++) {
            if (i % a == 0) {
                a += i;
            }
        }
        for (int i = 0; i < 100000000; i++) {
            if (i % a == 0) {
                a += i;
            }
        }


        return String.valueOf(a);
    }


}
