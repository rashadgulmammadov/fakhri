package az.vtb.grpc;

import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;
import java.util.logging.Logger;

public class GRPCServiceImpl implements GRPCService {

    private static final Logger LOGGER = Logger.getLogger("Test");
    int port = 9898;
    private Server server;
    @Override
    public void start() throws IOException, InterruptedException {
        server = ServerBuilder.forPort(port)
                .addService(new LocalServiceImpl())
                .build()
                .start();
        LOGGER.info("GRPC server start on " + port);
    }

    @Override
    public void blockUnitShutDown() throws InterruptedException {
        System.out.println("Daxil oldu");
        if (null != server) {
            server.awaitTermination();

        }

    }

}
