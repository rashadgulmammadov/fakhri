package az.vtb;

import az.vtb.grpc.GRPCService;
import az.vtb.grpc.GRPCServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Testing2rpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Testing2rpcApplication.class, args);
	}
	@Bean
	CommandLineRunner commandLineRunner() {
		return args -> {
			final GRPCService grpcService  = new GRPCServiceImpl();
			grpcService.start();
			grpcService.blockUnitShutDown();
		};
	}
}
