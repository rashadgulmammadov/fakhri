package az.vtb.rest.restmicroservis.controller;

import az.vtb.rest.restmicroservis.client.CallClient;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1")
public class CallController {

    private final CallClient callClient;
    @GetMapping()
    public String get(@RequestParam int a){
       return callClient.get(a);
    }
}
