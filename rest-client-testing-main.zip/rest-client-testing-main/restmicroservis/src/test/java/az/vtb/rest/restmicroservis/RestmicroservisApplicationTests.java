package az.vtb.rest.restmicroservis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestmicroservisApplicationTests {

	@Test
	void contextLoads() {
	}

}
