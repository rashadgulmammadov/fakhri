

package az.vtb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Faxri Nuruyev
 * @since 2022/11/3
 */
@RestController
@RequestMapping("/api")
public class GrpcClientController {

    @Autowired
    private GrpcClientService grpcClientService;

    @RequestMapping("/grpc")
    public String printMessage(@RequestParam(defaultValue = "1") int id) {
        return grpcClientService.sendMessage(id);
    }

}
