package az.vtb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * @author Faxri Nuruyev
 * @since 2022/11/3
 */
@SpringBootApplication
public class GrpcmicroservisApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrpcmicroservisApplication.class, args);
	}

}
