/**
 * Classes related to the gRPC client configuration.
 */

package az.vtb.config;
