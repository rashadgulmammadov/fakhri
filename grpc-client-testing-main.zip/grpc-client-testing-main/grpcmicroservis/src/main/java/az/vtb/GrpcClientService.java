package az.vtb;

import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.stereotype.Service;

/**
 * @author Faxri Nuruyev
 * @since 2022/11/3
 */
@Service
public class GrpcClientService {

    @GrpcClient("local-grpc-server")
    private LocalServiceGrpc.LocalServiceBlockingStub simpleStub;


    public String sendMessage(final int id) {
        try {
            final TestingGRPCApp.responseDTO response = this.simpleStub.pay(TestingGRPCApp.requestDTO.newBuilder().setId(id).build());
            return response.getResult();
        } catch (final StatusRuntimeException e) {
            return "FAILED with " + e.getStatus().getCode().name();
        }
    }

}
